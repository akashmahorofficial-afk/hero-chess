# Hero Chess
Android chess (Jetpack Compose) with a themeable piece set.
Add your own art to `app/src/main/res/drawable` as `w_king`, `b_queen`, etc.
Every push builds a debug APK via GitHub Actions (Actions tab > latest run > Artifacts).
