package com.example.herochess

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

/**
 * PIECE THEME
 * Edit the names/glyphs below. To use your own artwork, add PNG/WebP files to
 * res/drawable named  w_king, w_queen, w_rook, w_bishop, w_knight, w_pawn
 * and b_king ... b_pawn. If a file exists it is used instead of the glyph.
 */
object PieceTheme {
    val names = mapOf(
        'k' to "Sovereign", 'q' to "Sorceress", 'r' to "Titan",
        'b' to "Mystic", 'n' to "Ranger", 'p' to "Recruit"
    )
    val glyphs = mapOf('k' to "♚", 'q' to "♛", 'r' to "♜", 'b' to "♝", 'n' to "♞", 'p' to "♟")
    val files = mapOf('k' to "king", 'q' to "queen", 'r' to "rook", 'b' to "bishop", 'n' to "knight", 'p' to "pawn")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Surface(Modifier.fillMaxSize()) { GameScreen() } } }
    }
}

@Composable
fun GameScreen() {
    var board by remember { mutableStateOf(Board()) }
    var sel by remember { mutableStateOf<Pair<Int, Int>?>(null) }
    val status = board.status()
    val legal = remember(board) { board.legalMoves() }
    val targets = sel?.let { s -> legal.filter { it.fr == s.first && it.fc == s.second } } ?: emptyList()

    LaunchedEffect(board) {
        if (!board.whiteTurn && board.status() == null) {
            delay(400)
            board.bestMove()?.let { board = board.apply(it) }
        }
    }

    fun tap(r: Int, c: Int) {
        if (status != null || !board.whiteTurn) return
        val m = targets.firstOrNull { it.tr == r && it.tc == c }
        if (m != null) { board = board.apply(m); sel = null; return }
        val p = board.b[r][c]
        sel = if (p != '.' && p.isUpperCase()) r to c else null
    }

    Column(
        Modifier.fillMaxSize().padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("Hero Chess", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text(
            status ?: if (board.inCheck(board.whiteTurn)) "Check!" else if (board.whiteTurn) "Your move" else "Thinking…",
            Modifier.padding(8.dp)
        )
        for (r in 0..7) Row {
            for (c in 0..7) {
                val dark = (r + c) % 2 == 1
                val isSel = sel == r to c
                val isTarget = targets.any { it.tr == r && it.tc == c }
                val bg = when {
                    isSel -> Color(0xFFF6E05E)
                    isTarget -> Color(0xFF7BC47F)
                    dark -> Color(0xFF5B4B8A)
                    else -> Color(0xFFD8CFF0)
                }
                Box(
                    Modifier.weight(1f).aspectRatio(1f).background(bg).clickable { tap(r, c) },
                    contentAlignment = Alignment.Center
                ) { PieceView(board.b[r][c]) }
            }
        }
        Spacer(Modifier.height(12.dp))
        Button(onClick = { board = Board(); sel = null }) { Text("New game") }
    }
}

@Composable
fun PieceView(p: Char) {
    if (p == '.') return
    val white = p.isUpperCase()
    val t = p.lowercaseChar()
    val ctx = LocalContext.current
    val resName = "${if (white) "w" else "b"}_${PieceTheme.files[t]}"
    val id = ctx.resources.getIdentifier(resName, "drawable", ctx.packageName)
    if (id != 0) {
        Image(painterResource(id), PieceTheme.names[t], Modifier.fillMaxSize().padding(2.dp))
    } else {
        HeroPiece(p, white, Modifier.fillMaxSize().padding(2.dp))
    }
}
