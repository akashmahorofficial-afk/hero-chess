package com.example.herochess

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke

/** Original hero art drawn on a 100x100 grid. Gold/teal = White team, crimson/charcoal = Black team. */
@Composable
fun HeroPiece(type: Char, white: Boolean, modifier: Modifier = Modifier) {
    val main = if (white) Color(0xFFF2C14E) else Color(0xFFB23A48)
    val dark = if (white) Color(0xFF1F6F78) else Color(0xFF2B2B33)
    val skin = Color(0xFFF1C9A5)
    val glow = Color(0xFF80DEEA)
    val wood = Color(0xFF8D6E63)
    val gold = Color(0xFFFFE082)

    Canvas(modifier) {
        val s = size.minDimension / 100f
        fun c(x: Float, y: Float) = Offset(x * s, y * s)
        fun circle(col: Color, x: Float, y: Float, r: Float) = drawCircle(col, r * s, c(x, y))
        fun rect(col: Color, x: Float, y: Float, w: Float, h: Float) =
            drawRect(col, c(x, y), Size(w * s, h * s))
        fun poly(col: Color, vararg p: Pair<Float, Float>) {
            val path = Path()
            path.moveTo(p[0].first * s, p[0].second * s)
            for (i in 1 until p.size) path.lineTo(p[i].first * s, p[i].second * s)
            path.close()
            drawPath(path, col)
        }

        rect(dark, 22f, 90f, 56f, 6f) // pedestal

        when (type.lowercaseChar()) {
            'k' -> { // Sovereign: crown + cape
                poly(dark, 26f to 90f, 34f to 46f, 66f to 46f, 74f to 90f)
                poly(main, 32f to 90f, 39f to 50f, 61f to 50f, 68f to 90f)
                circle(skin, 50f, 38f, 12f)
                poly(gold, 37f to 28f, 39f to 12f, 45f to 21f, 50f to 8f, 55f to 21f, 61f to 12f, 63f to 28f)
                circle(dark, 50f, 66f, 5f)
            }
            'q' -> { // Sorceress: flowing hair + orb staff
                circle(dark, 50f, 36f, 16f)
                poly(main, 30f to 90f, 40f to 50f, 60f to 50f, 70f to 90f)
                circle(skin, 50f, 38f, 11f)
                rect(wood, 76f, 28f, 4f, 62f)
                circle(glow, 78f, 24f, 8f)
                poly(gold, 50f to 56f, 55f to 64f, 50f to 72f, 45f to 64f)
            }
            'r' -> { // Titan: huge shoulders + battlement helm
                rect(main, 16f, 48f, 68f, 20f)
                rect(main, 28f, 62f, 44f, 28f)
                rect(dark, 40f, 44f, 20f, 8f)
                circle(skin, 50f, 38f, 11f)
                rect(dark, 36f, 22f, 8f, 9f)
                rect(dark, 46f, 22f, 8f, 9f)
                rect(dark, 56f, 22f, 8f, 9f)
                rect(dark, 36f, 28f, 28f, 5f)
            }
            'b' -> { // Mystic: pointed hood + orb
                poly(dark, 50f to 6f, 28f to 52f, 72f to 52f)
                poly(main, 32f to 90f, 40f to 50f, 60f to 50f, 68f to 90f)
                circle(skin, 50f, 40f, 9f)
                circle(glow, 50f, 70f, 7f)
            }
            'n' -> { // Ranger: hood + bow
                poly(main, 32f to 90f, 40f to 50f, 60f to 50f, 68f to 90f)
                circle(skin, 50f, 40f, 10f)
                poly(dark, 35f to 40f, 50f to 18f, 65f to 40f, 50f to 34f)
                drawArc(wood, -70f, 140f, false, c(52f, 18f), Size(34f * s, 62f * s), style = Stroke(4f * s))
                drawLine(dark, c(70f, 49f), c(48f, 49f), 2f * s)
                poly(gold, 44f to 49f, 50f to 45f, 50f to 53f)
            }
            else -> { // Recruit: masked rookie
                poly(main, 34f to 90f, 40f to 58f, 60f to 58f, 66f to 90f)
                circle(skin, 50f, 46f, 11f)
                rect(dark, 39f, 41f, 22f, 7f)
                circle(Color.White, 45f, 44.5f, 2f)
                circle(Color.White, 55f, 44.5f, 2f)
                rect(dark, 44f, 66f, 12f, 6f)
            }
        }
    }
}
