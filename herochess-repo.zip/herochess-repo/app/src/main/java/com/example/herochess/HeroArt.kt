package com.example.herochess

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp

/** Original 3D-style hero art (gradient-shaded). White team = gold/teal, Black team = crimson/charcoal. */
@Composable
fun HeroPiece(type: Char, white: Boolean, modifier: Modifier = Modifier) {
    val main = if (white) Color(0xFFF2C14E) else Color(0xFFB23A48)
    val dark = if (white) Color(0xFF1F6F78) else Color(0xFF2B2B33)
    val skin = Color(0xFFF1C9A5)
    val glow = Color(0xFF80DEEA)
    val wood = Color(0xFF8D6E63)
    val gold = Color(0xFFFFD54F)
    val steel = Color(0xFFB0BEC5)

    Canvas(modifier) {
        val s = size.minDimension / 100f
        fun c(x: Float, y: Float) = Offset(x * s, y * s)
        fun hi(col: Color) = lerp(col, Color.White, 0.45f)
        fun lo(col: Color) = lerp(col, Color.Black, 0.5f)

        fun sphere(col: Color, x: Float, y: Float, r: Float) {
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(hi(col), col, lo(col)),
                    center = c(x - r * 0.35f, y - r * 0.4f),
                    radius = r * 1.7f * s
                ),
                radius = r * s,
                center = c(x, y)
            )
        }
        fun block(col: Color, x: Float, y: Float, w: Float, h: Float, round: Float = 3f) {
            drawRoundRect(
                brush = Brush.horizontalGradient(
                    listOf(lo(col), col, hi(col), col, lo(col)),
                    startX = x * s, endX = (x + w) * s
                ),
                topLeft = c(x, y),
                size = Size(w * s, h * s),
                cornerRadius = CornerRadius(round * s)
            )
        }
        fun poly(col: Color, vararg p: Pair<Float, Float>) {
            val path = Path()
            path.moveTo(p[0].first * s, p[0].second * s)
            for (i in 1 until p.size) path.lineTo(p[i].first * s, p[i].second * s)
            path.close()
            val minX = p.minOf { it.first }
            val maxX = p.maxOf { it.first }
            drawPath(
                path,
                Brush.horizontalGradient(
                    listOf(lo(col), col, hi(col), col, lo(col)),
                    startX = minX * s, endX = maxX * s
                )
            )
        }
        fun face(x: Float, y: Float, r: Float) {
            sphere(skin, x, y, r)
            drawCircle(Color(0xFF1B1B1B), 1.3f * s, c(x - r * 0.4f, y))
            drawCircle(Color(0xFF1B1B1B), 1.3f * s, c(x + r * 0.4f, y))
        }

        // ground shadow + pedestal
        drawOval(Color(0x66000000), c(18f, 87f), Size(64f * s, 12f * s))
        block(dark, 24f, 88f, 52f, 6f, 3f)

        when (type.lowercaseChar()) {
            'k' -> { // Sovereign: armored king with cape, crown and sword
                poly(dark, 26f to 90f, 33f to 46f, 67f to 46f, 74f to 90f)
                block(main, 33f, 48f, 34f, 40f, 6f)
                block(dark, 33f, 68f, 34f, 5f, 2f)
                sphere(main, 31f, 50f, 8f)
                sphere(main, 69f, 50f, 8f)
                block(steel, 78f, 26f, 4f, 36f, 1f)
                block(gold, 73f, 62f, 14f, 4f, 1f)
                block(wood, 78f, 66f, 4f, 10f, 1f)
                face(50f, 36f, 12f)
                poly(gold, 38f to 27f, 39f to 12f, 45f to 20f, 50f to 8f, 55f to 20f, 61f to 12f, 62f to 27f)
                sphere(Color(0xFFE53935), 50f, 22f, 2.6f)
            }
            'q' -> { // Sorceress: long hair, robe, orb staff
                sphere(dark, 50f, 38f, 17f)
                poly(main, 28f to 90f, 40f to 50f, 60f to 50f, 72f to 90f)
                face(50f, 38f, 11f)
                poly(gold, 43f to 28f, 44f to 20f, 50f to 25f, 56f to 20f, 57f to 28f)
                sphere(Color(0xFFFF8A80), 50f, 62f, 4f)
                block(wood, 76f, 28f, 4f, 62f, 2f)
                sphere(glow, 78f, 24f, 8f)
            }
            'r' -> { // Titan: horned brawler with shield and hammer (no castle shapes)
                block(main, 28f, 58f, 44f, 32f, 6f)
                block(dark, 34f, 52f, 32f, 20f, 5f)
                sphere(main, 22f, 52f, 11f)
                sphere(main, 78f, 52f, 11f)
                sphere(dark, 17f, 70f, 12f)
                sphere(gold, 17f, 70f, 4f)
                block(wood, 83f, 28f, 4f, 52f, 1f)
                block(steel, 74f, 22f, 22f, 12f, 3f)
                sphere(skin, 85f, 74f, 6f)
                face(50f, 40f, 11f)
                poly(dark, 38f to 38f, 40f to 26f, 50f to 22f, 60f to 26f, 62f to 38f, 58f to 31f, 42f to 31f)
                poly(Color(0xFFECEFF1), 39f to 30f, 28f to 14f, 43f to 25f)
                poly(Color(0xFFECEFF1), 61f to 30f, 72f to 14f, 57f to 25f)
            }
            'b' -> { // Mystic: hooded robe with orb
                poly(main, 30f to 90f, 40f to 50f, 60f to 50f, 70f to 90f)
                poly(dark, 50f to 6f, 28f to 52f, 72f to 52f)
                face(50f, 43f, 8f)
                sphere(glow, 50f, 72f, 7f)
            }
            'n' -> { // Ranger: hooded archer
                poly(main, 32f to 90f, 40f to 50f, 60f to 50f, 68f to 90f)
                face(50f, 40f, 10f)
                poly(dark, 35f to 40f, 50f to 16f, 65f to 40f, 50f to 33f)
                drawArc(wood, -70f, 140f, false, c(52f, 18f), Size(34f * s, 62f * s), style = Stroke(4f * s))
                drawLine(Color(0xFF455A64), c(70f, 49f), c(46f, 49f), 2f * s)
                poly(gold, 44f to 49f, 50f to 45f, 50f to 53f)
            }
            else -> { // Recruit: masked rookie
                block(main, 36f, 56f, 28f, 34f, 6f)
                sphere(main, 33f, 60f, 6f)
                sphere(main, 67f, 60f, 6f)
                sphere(skin, 50f, 45f, 11f)
                block(dark, 39f, 40f, 22f, 7f, 3f)
                sphere(Color.White, 45f, 43.5f, 2.2f)
                sphere(Color.White, 55f, 43.5f, 2.2f)
            }
        }
    }
}
