package com.example.herochess

data class Move(val fr: Int, val fc: Int, val tr: Int, val tc: Int)

/** rights bitmask: 1 = White kingside, 2 = White queenside, 4 = Black kingside, 8 = Black queenside */
class Board(val b: Array<CharArray> = initial(), val whiteTurn: Boolean = true, val rights: Int = 15) {

    companion object {
        fun initial(): Array<CharArray> {
            val g = Array(8) { CharArray(8) { '.' } }
            val back = "rnbqkbnr"
            for (c in 0..7) {
                g[0][c] = back[c]; g[1][c] = 'p'
                g[6][c] = 'P'; g[7][c] = back[c].uppercaseChar()
            }
            return g
        }
        private val values = mapOf('p' to 1, 'n' to 3, 'b' to 3, 'r' to 5, 'q' to 9, 'k' to 0)
    }

    private fun inb(r: Int, c: Int) = r in 0..7 && c in 0..7

    private fun pseudo(r: Int, c: Int): List<Move> {
        val p = b[r][c]
        if (p == '.') return emptyList()
        val w = p.isUpperCase()
        val out = mutableListOf<Move>()
        fun enemy(x: Int, y: Int) = b[x][y] != '.' && b[x][y].isUpperCase() != w
        fun free(x: Int, y: Int) = b[x][y] == '.'
        when (p.lowercaseChar()) {
            'p' -> {
                val d = if (w) -1 else 1
                val start = if (w) 6 else 1
                if (inb(r + d, c) && free(r + d, c)) {
                    out += Move(r, c, r + d, c)
                    if (r == start && free(r + 2 * d, c)) out += Move(r, c, r + 2 * d, c)
                }
                for (dc in intArrayOf(-1, 1))
                    if (inb(r + d, c + dc) && enemy(r + d, c + dc)) out += Move(r, c, r + d, c + dc)
            }
            'n' -> for ((dr, dc) in listOf(1 to 2, 2 to 1, -1 to 2, -2 to 1, 1 to -2, 2 to -1, -1 to -2, -2 to -1)) {
                val x = r + dr; val y = c + dc
                if (inb(x, y) && (free(x, y) || enemy(x, y))) out += Move(r, c, x, y)
            }
            else -> {
                val diag = listOf(1 to 1, 1 to -1, -1 to 1, -1 to -1)
                val orth = listOf(1 to 0, -1 to 0, 0 to 1, 0 to -1)
                val t = p.lowercaseChar()
                val dirs = when (t) { 'b' -> diag; 'r' -> orth; else -> diag + orth }
                val single = t == 'k'
                for ((dr, dc) in dirs) {
                    var x = r + dr; var y = c + dc
                    while (inb(x, y)) {
                        if (free(x, y)) out += Move(r, c, x, y)
                        else { if (enemy(x, y)) out += Move(r, c, x, y); break }
                        if (single) break
                        x += dr; y += dc
                    }
                }
            }
        }
        return out
    }

    fun apply(m: Move): Board {
        val g = Array(8) { b[it].clone() }
        var p = g[m.fr][m.fc]
        if (p == 'P' && m.tr == 0) p = 'Q'
        if (p == 'p' && m.tr == 7) p = 'q'
        g[m.tr][m.tc] = p
        g[m.fr][m.fc] = '.'
        // castling: king moves two squares, rook jumps over
        if ((p == 'K' || p == 'k') && Math.abs(m.tc - m.fc) == 2) {
            if (m.tc == 6) { g[m.tr][5] = g[m.tr][7]; g[m.tr][7] = '.' }
            else { g[m.tr][3] = g[m.tr][0]; g[m.tr][0] = '.' }
        }
        var r = rights
        if (p == 'K') r = r and (3.inv())
        if (p == 'k') r = r and (12.inv())
        fun corner(row: Int, col: Int) {
            val bit = when {
                row == 7 && col == 7 -> 1
                row == 7 && col == 0 -> 2
                row == 0 && col == 7 -> 4
                row == 0 && col == 0 -> 8
                else -> 0
            }
            r = r and (bit.inv())
        }
        corner(m.fr, m.fc)
        corner(m.tr, m.tc)
        return Board(g, !whiteTurn, r)
    }

    fun inCheck(white: Boolean): Boolean {
        val k = if (white) 'K' else 'k'
        var kr = -1; var kc = -1
        for (r in 0..7) for (c in 0..7) if (b[r][c] == k) { kr = r; kc = c }
        if (kr < 0) return true
        val opp = Board(b, !white)
        for (r in 0..7) for (c in 0..7) {
            val p = b[r][c]
            if (p != '.' && p.isUpperCase() != white)
                if (opp.pseudo(r, c).any { it.tr == kr && it.tc == kc }) return true
        }
        return false
    }

    private fun kingSafeAt(row: Int, col: Int): Boolean {
        val g = Array(8) { b[it].clone() }
        g[row][col] = g[row][4]
        g[row][4] = '.'
        return !Board(g, whiteTurn, 0).inCheck(whiteTurn)
    }

    fun legalMoves(): List<Move> {
        val out = mutableListOf<Move>()
        for (r in 0..7) for (c in 0..7) {
            val p = b[r][c]
            if (p != '.' && p.isUpperCase() == whiteTurn)
                for (m in pseudo(r, c)) if (!apply(m).inCheck(whiteTurn)) out += m
        }
        // castling
        val row = if (whiteTurn) 7 else 0
        val king = if (whiteTurn) 'K' else 'k'
        val rook = if (whiteTurn) 'R' else 'r'
        val kBit = if (whiteTurn) 1 else 4
        val qBit = if (whiteTurn) 2 else 8
        if (b[row][4] == king && !inCheck(whiteTurn)) {
            if ((rights and kBit) != 0 && b[row][7] == rook &&
                b[row][5] == '.' && b[row][6] == '.' &&
                kingSafeAt(row, 5) && kingSafeAt(row, 6)
            ) out += Move(row, 4, row, 6)
            if ((rights and qBit) != 0 && b[row][0] == rook &&
                b[row][1] == '.' && b[row][2] == '.' && b[row][3] == '.' &&
                kingSafeAt(row, 3) && kingSafeAt(row, 2)
            ) out += Move(row, 4, row, 2)
        }
        return out
    }

    /** null while the game is running. */
    fun status(): String? {
        if (legalMoves().isNotEmpty()) return null
        return if (inCheck(whiteTurn)) "Checkmate — ${if (whiteTurn) "Black" else "White"} wins"
        else "Stalemate"
    }

    private fun material(): Int {
        var s = 0
        for (row in b) for (p in row) if (p != '.') {
            val v = values[p.lowercaseChar()] ?: 0
            s += if (p.isUpperCase()) v else -v
        }
        return s
    }

    /** Simple 2-ply AI for Black. */
    fun bestMove(): Move? {
        val moves = legalMoves().shuffled()
        var best: Move? = null
        var bestScore = Int.MAX_VALUE
        for (m in moves) {
            val n = apply(m)
            val replies = n.legalMoves()
            val score = if (replies.isEmpty()) (if (n.inCheck(n.whiteTurn)) -1000 else 0)
            else replies.maxOf { n.apply(it).material() }
            if (score < bestScore) { bestScore = score; best = m }
        }
        return best
    }
}
