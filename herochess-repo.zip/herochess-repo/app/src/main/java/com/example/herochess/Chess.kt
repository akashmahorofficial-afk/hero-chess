package com.example.herochess

data class Move(val fr: Int, val fc: Int, val tr: Int, val tc: Int)

class Board(val b: Array<CharArray> = initial(), val whiteTurn: Boolean = true) {

    companion object {
        fun initial(): Array<CharArray> {
            val g = Array(8) { CharArray(8) { '.' } }
            val back = "rnbqkbnr"
            for (c in 0..7) {
                g[0][c] = back[c]; g[1][c] = 'p'
                g[6][c] = 'P'; g[7][c] = back[c].uppercaseChar()
            }
            return g
        }
        private val values = mapOf('p' to 1, 'n' to 3, 'b' to 3, 'r' to 5, 'q' to 9, 'k' to 0)
    }

    private fun inb(r: Int, c: Int) = r in 0..7 && c in 0..7

    private fun pseudo(r: Int, c: Int): List<Move> {
        val p = b[r][c]
        if (p == '.') return emptyList()
        val w = p.isUpperCase()
        val out = mutableListOf<Move>()
        fun enemy(x: Int, y: Int) = b[x][y] != '.' && b[x][y].isUpperCase() != w
        fun free(x: Int, y: Int) = b[x][y] == '.'
        when (p.lowercaseChar()) {
            'p' -> {
                val d = if (w) -1 else 1
                val start = if (w) 6 else 1
                if (inb(r + d, c) && free(r + d, c)) {
                    out += Move(r, c, r + d, c)
                    if (r == start && free(r + 2 * d, c)) out += Move(r, c, r + 2 * d, c)
                }
                for (dc in intArrayOf(-1, 1))
                    if (inb(r + d, c + dc) && enemy(r + d, c + dc)) out += Move(r, c, r + d, c + dc)
            }
            'n' -> for ((dr, dc) in listOf(1 to 2, 2 to 1, -1 to 2, -2 to 1, 1 to -2, 2 to -1, -1 to -2, -2 to -1)) {
                val x = r + dr; val y = c + dc
                if (inb(x, y) && (free(x, y) || enemy(x, y))) out += Move(r, c, x, y)
            }
            else -> {
                val diag = listOf(1 to 1, 1 to -1, -1 to 1, -1 to -1)
                val orth = listOf(1 to 0, -1 to 0, 0 to 1, 0 to -1)
                val t = p.lowercaseChar()
                val dirs = when (t) { 'b' -> diag; 'r' -> orth; else -> diag + orth }
                val single = t == 'k'
                for ((dr, dc) in dirs) {
                    var x = r + dr; var y = c + dc
                    while (inb(x, y)) {
                        if (free(x, y)) out += Move(r, c, x, y)
                        else { if (enemy(x, y)) out += Move(r, c, x, y); break }
                        if (single) break
                        x += dr; y += dc
                    }
                }
            }
        }
        return out
    }

    fun apply(m: Move): Board {
        val g = Array(8) { b[it].clone() }
        var p = g[m.fr][m.fc]
        if (p == 'P' && m.tr == 0) p = 'Q'
        if (p == 'p' && m.tr == 7) p = 'q'
        g[m.tr][m.tc] = p
        g[m.fr][m.fc] = '.'
        return Board(g, !whiteTurn)
    }

    fun inCheck(white: Boolean): Boolean {
        val k = if (white) 'K' else 'k'
        var kr = -1; var kc = -1
        for (r in 0..7) for (c in 0..7) if (b[r][c] == k) { kr = r; kc = c }
        if (kr < 0) return true
        val opp = Board(b, !white)
        for (r in 0..7) for (c in 0..7) {
            val p = b[r][c]
            if (p != '.' && p.isUpperCase() != white)
                if (opp.pseudo(r, c).any { it.tr == kr && it.tc == kc }) return true
        }
        return false
    }

    fun legalMoves(): List<Move> {
        val out = mutableListOf<Move>()
        for (r in 0..7) for (c in 0..7) {
            val p = b[r][c]
            if (p != '.' && p.isUpperCase() == whiteTurn)
                for (m in pseudo(r, c)) if (!apply(m).inCheck(whiteTurn)) out += m
        }
        return out
    }

    /** null while the game is running. */
    fun status(): String? {
        if (legalMoves().isNotEmpty()) return null
        return if (inCheck(whiteTurn)) "Checkmate — ${if (whiteTurn) "Black" else "White"} wins"
        else "Stalemate"
    }

    private fun material(): Int {
        var s = 0
        for (row in b) for (p in row) if (p != '.') {
            val v = values[p.lowercaseChar()] ?: 0
            s += if (p.isUpperCase()) v else -v
        }
        return s
    }

    /** Simple 2-ply AI for Black. */
    fun bestMove(): Move? {
        val moves = legalMoves().shuffled()
        var best: Move? = null
        var bestScore = Int.MAX_VALUE
        for (m in moves) {
            val n = apply(m)
            val replies = n.legalMoves()
            val score = if (replies.isEmpty()) (if (n.inCheck(n.whiteTurn)) -1000 else 0)
            else replies.maxOf { n.apply(it).material() }
            if (score < bestScore) { bestScore = score; best = m }
        }
        return best
    }
}
